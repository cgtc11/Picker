# -*- coding: utf-8 -*-
import json
import os
import math
import bpy
from PySide6 import QtWidgets, QtCore, QtGui

# --- スタイル設定 ---
STYLESHEET = """
    QWidget { background-color: #2b2b2b; color: #dcdcdc; font-family: 'Segoe UI', sans-serif; font-size: 12px; }
    QGroupBox { border: 1px solid #3a3a3a; margin-top: 10px; padding-top: 10px; font-weight: bold; }
    QPushButton { background-color: #3f3f3f; border: 1px solid #555; border-radius: 3px; padding: 2px; color: #ffffff; }
    QPushButton:hover { background-color: #4f4f4f; }
    QLineEdit { background-color: #1a1a1a; color: #ffffff; border: 1px solid #333; padding: 2px; }
    QComboBox { background-color: #1a1a1a; color: #ffffff; border: 1px solid #333; padding: 2px; }
    QListWidget { background-color: #1a1a1a; border: 1px solid #333; outline: none; }
    QListWidget::item:selected { background-color: #3d5a73; }
    QLabel#DragLabel { color: #888; font-weight: bold; }
    QLabel#DragLabel:hover { color: #aaa; }
"""

SHAPE_TYPES = ["rect", "rect_fill", "circle", "circle_fill", "cross", "diamond", "diamond_fill", "tri_up", "tri_up_fill", "tri_down", "tri_down_fill", "tri_left", "tri_left_fill", "tri_right", "tri_right_fill", "double_circle", "star", "star_fill"]

def draw_shape(painter, t, sr, color, is_selected):
    painter.setPen(QtGui.QPen(color, 4 if is_selected else 1))
    if t == "rect": painter.drawRect(sr)
    elif t == "rect_fill": painter.fillRect(sr, color)
    elif t == "circle": painter.drawEllipse(sr)
    elif t == "circle_fill": (painter.setBrush(color), painter.drawEllipse(sr), painter.setBrush(QtCore.Qt.NoBrush))
    elif t == "cross":
        cx, cy = sr.center().x(), sr.center().y()
        painter.drawLine(sr.left(), cy, sr.right(), cy); painter.drawLine(cx, sr.top(), cx, sr.bottom())
    elif "diamond" in t:
        poly = QtGui.QPolygon([QtCore.QPoint(sr.center().x(), sr.top()), QtCore.QPoint(sr.right(), sr.center().y()), QtCore.QPoint(sr.center().x(), sr.bottom()), QtCore.QPoint(sr.left(), sr.center().y())])
        if "fill" in t: painter.setBrush(color)
        painter.drawPolygon(poly); painter.setBrush(QtCore.Qt.NoBrush)
    elif "tri_" in t:
        pts = []
        if "up" in t: pts = [sr.bottomLeft(), sr.bottomRight(), QtCore.QPoint(sr.center().x(), sr.top())]
        elif "down" in t: pts = [sr.topLeft(), sr.topRight(), QtCore.QPoint(sr.center().x(), sr.bottom())]
        elif "left" in t: pts = [sr.topRight(), sr.bottomRight(), QtCore.QPoint(sr.left(), sr.center().y())]
        elif "right" in t: pts = [sr.topLeft(), sr.bottomLeft(), QtCore.QPoint(sr.right(), sr.center().y())]
        if pts: poly = QtGui.QPolygon(pts); (painter.setBrush(color) if "fill" in t else None); painter.drawPolygon(poly); painter.setBrush(QtCore.Qt.NoBrush)
    elif t == "double_circle":
        painter.drawEllipse(sr)
        inner = sr.adjusted(sr.width()*0.2, sr.height()*0.2, -sr.width()*0.2, -sr.height()*0.2)
        painter.drawEllipse(inner)
    elif "star" in t:
        poly = QtGui.QPolygon(); center = sr.center(); ro = min(sr.width(), sr.height())/2; ri = ro/2.5
        for j in range(10):
            r = ro if j%2==0 else ri; angle = (j*36-90)*math.pi/180; poly << QtCore.QPoint(center.x()+r*math.cos(angle), center.y()+r*math.sin(angle))
        if "fill" in t: painter.setBrush(color)
        painter.drawPolygon(poly); painter.setBrush(QtCore.Qt.NoBrush)
    else: painter.drawRect(sr)

def create_shape_icon(shape_type, color=QtCore.Qt.white):
    pixmap = QtGui.QPixmap(20, 20); pixmap.fill(QtCore.Qt.transparent)
    painter = QtGui.QPainter(pixmap); painter.setRenderHint(QtGui.QPainter.Antialiasing)
    draw_shape(painter, shape_type, QtCore.QRect(2, 2, 16, 16), QtGui.QColor(color), False)
    painter.end(); return QtGui.QIcon(pixmap)

class DragLabel(QtWidgets.QLabel):
    def __init__(self, text, target_spin, parent=None):
        super().__init__(text, parent)
        self.setObjectName("DragLabel"); self.target_spin = target_spin; self.setCursor(QtCore.Qt.SizeHorCursor); self.last_x = 0
    def mousePressEvent(self, event): self.last_x = event.globalPos().x()
    def mouseMoveEvent(self, event):
        if event.buttons() & QtCore.Qt.LeftButton:
            dx = event.globalPos().x() - self.last_x
            self.target_spin.setValue(self.target_spin.value() + dx); self.last_x = event.globalPos().x()

class ClickRegion:
    def __init__(self, names, rect_data, color, shape_type="rect", next_json=""):
        self.names = names if isinstance(names, list) else [names]
        self.rect = QtCore.QRect(*rect_data); self.color = QtGui.QColor(*color) if isinstance(color, list) else QtGui.QColor(color)
        self.shape_type = shape_type; self.next_json = next_json

class ListColorItem(QtWidgets.QWidget):
    color_changed = QtCore.Signal(object, QtGui.QColor); rect_changed = QtCore.Signal(object, str, int)
    names_changed = QtCore.Signal(object, list); type_changed = QtCore.Signal(object, str); next_json_changed = QtCore.Signal(object, str)
    def __init__(self, names, rect, color, shape_type, next_json, parent=None):
        super().__init__(parent); self.block_ui_signals = False
        layout = QtWidgets.QHBoxLayout(self); layout.setContentsMargins(0, 2, 5, 2); layout.setSpacing(3); layout.addSpacing(40) 
        self.names_edit = QtWidgets.QLineEdit(); self.names_edit.editingFinished.connect(self.on_ui_data_changed); layout.addWidget(self.names_edit, 1)
        self.btn_path = QtWidgets.QPushButton("..."); self.btn_path.setFixedWidth(22); self.btn_path.clicked.connect(self.browse_path); layout.addWidget(self.btn_path)
        self.type_combo = QtWidgets.QComboBox(); self.type_combo.setIconSize(QtCore.QSize(16, 16)); self.type_combo.setFixedWidth(55)
        for st in SHAPE_TYPES: self.type_combo.addItem(create_shape_icon(st, color), "", st)
        self.type_combo.currentIndexChanged.connect(self.on_type_ui_changed); layout.addWidget(self.type_combo)
        self.spins = {}; self.labels = []
        for lbl_t, key in [("X", "x"), ("Y", "y"), ("W", "w"), ("H", "h")]:
            sb = QtWidgets.QSpinBox(); sb.setButtonSymbols(QtWidgets.QSpinBox.NoButtons); sb.setRange(-20000, 20000); sb.setFixedWidth(40)
            sb.valueChanged.connect(lambda val, k=key: self.on_rect_ui_changed(k, val))
            lbl = DragLabel(lbl_t, sb); lbl.setFixedWidth(12); self.labels.append(lbl); layout.addWidget(lbl); layout.addWidget(sb); self.spins[key] = sb
        self.color_btn = QtWidgets.QPushButton("■"); self.color_btn.setFixedSize(20, 20); self.color_btn.clicked.connect(self.pick_new_color); layout.addWidget(self.color_btn)
        self.update_ui_silently(names, rect, color, shape_type, next_json)

    def update_ui_silently(self, names, rect, color, shape_type, next_json):
        self.block_ui_signals = True; self.current_color = color
        txt = os.path.basename(next_json) if next_json else ", ".join(names)
        if self.names_edit.text() != txt: self.names_edit.setText(txt)
        self.spins["x"].setValue(rect.x()); self.spins["y"].setValue(rect.y()); self.spins["w"].setValue(rect.width()); self.spins["h"].setValue(rect.height())
        if shape_type in SHAPE_TYPES: self.type_combo.setCurrentIndex(SHAPE_TYPES.index(shape_type))
        self.color_btn.setStyleSheet(f"color: {color.name()}; background-color: #2b2b2b; border: 1px solid #555;")
        for i in range(self.type_combo.count()): self.type_combo.setItemIcon(i, create_shape_icon(SHAPE_TYPES[i], color))
        self.block_ui_signals = False

    def browse_path(self):
        p, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Select JSON", "", "*.json")
        if p: self.names_edit.setText(os.path.basename(p)); self.on_ui_data_changed()
    def on_ui_data_changed(self):
        if not self.block_ui_signals:
            t = self.names_edit.text()
            if t.endswith(".json"): self.next_json_changed.emit(self, t); self.names_changed.emit(self, [])
            else: self.next_json_changed.emit(self, ""); self.names_changed.emit(self, [n.strip() for n in t.split(",") if n.strip()])
    def on_rect_ui_changed(self, k, v):
        if not self.block_ui_signals: self.rect_changed.emit(self, k, v)
    def on_type_ui_changed(self, idx):
        if not self.block_ui_signals: self.type_changed.emit(self, SHAPE_TYPES[idx])
    def pick_new_color(self):
        c = QtWidgets.QColorDialog.getColor(self.current_color, self, "Color", QtWidgets.QColorDialog.ShowAlphaChannel)
        if c.isValid(): self.color_changed.emit(self, c)
    def set_edit_enabled(self, e):
        self.names_edit.setEnabled(e); self.color_btn.setEnabled(e); self.type_combo.setEnabled(e); self.btn_path.setEnabled(e)
        for sb in self.spins.values(): sb.setEnabled(e)
        for lb in self.labels: lb.setEnabled(e)

class ImageCanvas(QtWidgets.QLabel):
    request_deselect = QtCore.Signal(bool); region_clicked = QtCore.Signal(int, bool)
    multi_region_moved = QtCore.Signal(list, int, int); file_dropped = QtCore.Signal(str); pan_requested = QtCore.Signal(QtCore.QPoint)
    def __init__(self, parent=None):
        super().__init__(parent); self.start_pos = None; self.temp_rect = QtCore.QRect(); self.registered_items = []
        self.mode = "setup"; self.scale = 1.0; self.pixmap_original = None; self.last_pan_pos = None 
        self.selected_indices = set(); self.is_dragging_items = False; self.drag_start_pt = None
        self.setMouseTracking(True); self.setAcceptDrops(True); self.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        self.setStyleSheet("background-color: #1a1a1a; color: #555; border: 2px dashed #333;"); self.setText("DROP IMAGE OR JSON")

    def set_image(self, pix):
        self.pixmap_original = pix; self.scale = 1.0; self.update_canvas_size()
        self.setStyleSheet("background-color: #111; border: none;")

    def update_canvas_size(self):
        if self.pixmap_original: ns = self.pixmap_original.size() * self.scale; self.setPixmap(self.pixmap_original.scaled(ns, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation)); self.setFixedSize(ns)

    def paintEvent(self, event):
        super().paintEvent(event); painter = QtGui.QPainter(self); painter.setRenderHint(QtGui.QPainter.Antialiasing)
        for i, item in enumerate(self.registered_items):
            sr = QtCore.QRect(int(item.rect.x()*self.scale), int(item.rect.y()*self.scale), int(item.rect.width()*self.scale), int(item.rect.height()*self.scale))
            draw_shape(painter, item.shape_type, sr, item.color, i in self.selected_indices)
        if self.mode == "setup" and not self.temp_rect.isNull(): painter.setPen(QtGui.QPen(QtCore.Qt.red, 1, QtCore.Qt.DashLine)); painter.drawRect(self.temp_rect)

    def mousePressEvent(self, event):
        mod = event.modifiers(); pos = event.pos(); raw = QtCore.QPoint(int(pos.x() / self.scale), int(pos.y() / self.scale))
        is_mod = bool(mod & (QtCore.Qt.ControlModifier | QtCore.Qt.ShiftModifier))
        
        if event.button() == QtCore.Qt.MiddleButton or (event.button() == QtCore.Qt.LeftButton and mod & QtCore.Qt.AltModifier):
            self.last_pan_pos = event.globalPos(); self.setCursor(QtCore.Qt.ClosedHandCursor); return
        
        idx = -1
        for i, r in enumerate(self.registered_items):
            if r.rect.contains(raw): idx = i; break
        
        if idx != -1:
            item = self.registered_items[idx]
            if self.mode == "selector" and item.next_json and not is_mod: 
                target = item.next_json
                if not os.path.isabs(target) and self.window().current_json_path: target = os.path.join(os.path.dirname(self.window().current_json_path), target)
                self.window().load_json(target); return
            
            if self.mode == "setup":
                if idx not in self.selected_indices or is_mod:
                    self.region_clicked.emit(idx, is_mod)
                self.is_dragging_items = True; self.drag_start_pt = raw
            else:
                self.region_clicked.emit(idx, is_mod)
                if not item.next_json: self.execute_blender_select(item.names, is_mod)
        else:
            self.request_deselect.emit(is_mod)
            if self.mode == "setup": 
                self.start_pos = pos
                self.temp_rect = QtCore.QRect()
        self.update()

    def execute_blender_select(self, names, is_mod):
        def _task():
            if not is_mod: bpy.ops.object.select_all(action='DESELECT')
            for n in names:
                obj = bpy.data.objects.get(n); (obj.select_set(True) if obj else None)
        QtCore.QTimer.singleShot(0, _task)

    def mouseMoveEvent(self, event):
        if self.last_pan_pos: d = event.globalPos() - self.last_pan_pos; self.pan_requested.emit(d); self.last_pan_pos = event.globalPos(); return
        if self.is_dragging_items and self.drag_start_pt:
            raw = QtCore.QPoint(int(event.pos().x()/self.scale), int(event.pos().y()/self.scale))
            dx, dy = raw.x()-self.drag_start_pt.x(), raw.y()-self.drag_start_pt.y()
            if dx!=0 or dy!=0:
                self.multi_region_moved.emit(list(self.selected_indices), dx, dy)
                self.drag_start_pt = raw; self.update(); return
        if self.mode == "setup" and self.start_pos: 
            self.temp_rect = QtCore.QRect(self.start_pos, event.pos()).normalized()
            self.update()

    def mouseReleaseEvent(self, event):
        self.start_pos = self.last_pan_pos = None; self.is_dragging_items = False; self.setCursor(QtCore.Qt.ArrowCursor); self.update()

    def wheelEvent(self, event): self.scale *= (1.1 if event.angleDelta().y() > 0 else 0.9); self.scale = max(0.1, min(self.scale, 10.0)); self.update_canvas_size(); self.update()
    def dragEnterEvent(self, e): (e.acceptProposedAction() if e.mimeData().hasUrls() else None)
    def dropEvent(self, e): 
        for u in e.mimeData().urls(): self.file_dropped.emit(u.toLocalFile())
        e.acceptProposedAction()

class BlenderPickerEditor(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle("Blender Picker Editor"); self.resize(1100, 750); self.setStyleSheet(STYLESHEET)
        self.is_updating = False; self.current_json_path = ""; self.last_used_color = QtGui.QColor(255, 255, 255, 255)
        main_layout = QtWidgets.QVBoxLayout(self); self.splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        left_w = QtWidgets.QWidget(); left_v = QtWidgets.QVBoxLayout(left_w); self.scroll = QtWidgets.QScrollArea(); self.scroll.setWidgetResizable(True)
        self.canvas = ImageCanvas(); self.scroll.setWidget(self.canvas); left_v.addWidget(self.scroll)
        self.btn_mode = QtWidgets.QPushButton("Switch to SELECTOR Mode"); self.btn_mode.setCheckable(True); self.btn_mode.setFixedHeight(40); self.btn_mode.toggled.connect(self.toggle_mode); left_v.addWidget(self.btn_mode)
        right_w = QtWidgets.QWidget(); right_v = QtWidgets.QVBoxLayout(right_w); self.setup_group = QtWidgets.QGroupBox("Registration"); setup_v = QtWidgets.QVBoxLayout(self.setup_group)
        rep_h = QtWidgets.QHBoxLayout(); self.edit_f = QtWidgets.QLineEdit(); self.edit_r = QtWidgets.QLineEdit(); btn_rep = QtWidgets.QPushButton("Replace All")
        btn_rep.clicked.connect(self.batch_replace); rep_h.addWidget(self.edit_f); rep_h.addWidget(self.edit_r); rep_h.addWidget(btn_rep); setup_v.addLayout(rep_h)
        self.list_widget = QtWidgets.QListWidget(); self.list_widget.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection); self.list_widget.itemSelectionChanged.connect(self.on_list_selection_changed); setup_v.addWidget(self.list_widget)
        get_h = QtWidgets.QHBoxLayout(); self.edit_names = QtWidgets.QLineEdit(); btn_get = QtWidgets.QPushButton("Get Selected")
        btn_get.clicked.connect(self.update_names_from_blender); get_h.addWidget(self.edit_names); get_h.addWidget(btn_get); setup_v.addLayout(get_h)
        right_v.addWidget(self.setup_group)
        self.btn_reg = QtWidgets.QPushButton("Register Area"); self.btn_reg.setFixedHeight(30); self.btn_reg.clicked.connect(self.do_register)
        self.btn_del = QtWidgets.QPushButton("Delete Selected"); self.btn_del.setFixedHeight(30); self.btn_del.clicked.connect(self.delete_items); right_v.addWidget(self.btn_reg); right_v.addWidget(self.btn_del)
        file_h = QtWidgets.QHBoxLayout(); btn_save = QtWidgets.QPushButton("Save JSON"); btn_load = QtWidgets.QPushButton("Load JSON")
        btn_save.clicked.connect(self.save_json); btn_load.clicked.connect(lambda: self.load_json()); file_h.addWidget(btn_save); file_h.addWidget(btn_load); right_v.addLayout(file_h)
        self.splitter.addWidget(left_w); self.splitter.addWidget(right_w); self.splitter.setSizes([300, 800]); main_layout.addWidget(self.splitter)
        self.canvas.request_deselect.connect(self.handle_deselect); self.canvas.region_clicked.connect(self.handle_canvas_region_click)
        self.canvas.multi_region_moved.connect(self.handle_multi_move); self.canvas.file_dropped.connect(self.handle_drop_file); self.canvas.pan_requested.connect(self.handle_pan)

    def handle_deselect(self, is_mod):
        if not is_mod: self.list_widget.clearSelection(); self.canvas.selected_indices.clear(); self.canvas.update()
    def handle_canvas_region_click(self, row, is_mod):
        it = self.list_widget.item(row)
        if it:
            if is_mod: it.setSelected(not it.isSelected())
            else: self.list_widget.clearSelection(); it.setSelected(True); self.list_widget.scrollToItem(it)
    def on_list_selection_changed(self):
        self.canvas.selected_indices = {i.row() for i in self.list_widget.selectedIndexes()}; self.canvas.update()
    def _get_target_rows(self, widget):
        row = -1
        for i in range(self.list_widget.count()):
            if self.list_widget.itemWidget(self.list_widget.item(i)) == widget: row = i; break
        if row == -1: return set()
        sel = {i.row() for i in self.list_widget.selectedIndexes()}; return sel if row in sel else {row}
    def sync_multi_rect(self, widget, k, v):
        if self.is_updating: return
        try:
            self.is_updating = True; rows = self._get_target_rows(widget)
            for r in rows:
                if r < len(self.canvas.registered_items):
                    reg = self.canvas.registered_items[r]; rl = list(reg.rect.getRect())
                    rl[{"x":0,"y":1,"w":2,"h":3}[k]] = v; reg.rect = QtCore.QRect(*rl)
                    w = self.list_widget.itemWidget(self.list_widget.item(r)); (w.update_ui_silently(reg.names, reg.rect, reg.color, reg.shape_type, reg.next_json) if w else None)
            self.canvas.update()
        finally: self.is_updating = False
    def sync_multi_color(self, widget, c):
        if self.is_updating: return
        try:
            self.is_updating = True; self.last_used_color = c; rows = self._get_target_rows(widget)
            for r in rows:
                if r < len(self.canvas.registered_items):
                    reg = self.canvas.registered_items[r]; reg.color = c
                    w = self.list_widget.itemWidget(self.list_widget.item(r)); (w.update_ui_silently(reg.names, reg.rect, reg.color, reg.shape_type, reg.next_json) if w else None)
            self.canvas.update()
        finally: self.is_updating = False
    def sync_multi_type(self, widget, t):
        if self.is_updating: return
        try:
            self.is_updating = True; rows = self._get_target_rows(widget)
            for r in rows:
                if r < len(self.canvas.registered_items):
                    reg = self.canvas.registered_items[r]; reg.shape_type = t
                    w = self.list_widget.itemWidget(self.list_widget.item(r)); (w.update_ui_silently(reg.names, reg.rect, reg.color, reg.shape_type, reg.next_json) if w else None)
            self.canvas.update()
        finally: self.is_updating = False
    def sync_multi_names(self, widget, names):
        if self.is_updating: return
        try:
            self.is_updating = True; rows = self._get_target_rows(widget)
            for r in rows:
                if r < len(self.canvas.registered_items):
                    reg = self.canvas.registered_items[r]; reg.names = names
                    w = self.list_widget.itemWidget(self.list_widget.item(r)); (w.update_ui_silently(reg.names, reg.rect, reg.color, reg.shape_type, reg.next_json) if w else None)
        finally: self.is_updating = False
    def sync_multi_next_json(self, widget, p):
        if self.is_updating: return
        try:
            self.is_updating = True; rows = self._get_target_rows(widget)
            for r in rows:
                if r < len(self.canvas.registered_items):
                    reg = self.canvas.registered_items[r]; reg.next_json = p
                    w = self.list_widget.itemWidget(self.list_widget.item(r)); (w.update_ui_silently(reg.names, reg.rect, reg.color, reg.shape_type, reg.next_json) if w else None)
        finally: self.is_updating = False
    def handle_multi_move(self, rows, dx, dy):
        if self.is_updating: return
        try:
            self.is_updating = True
            for r in rows:
                if r < len(self.canvas.registered_items):
                    reg = self.canvas.registered_items[r]; reg.rect.translate(dx, dy)
                    w = self.list_widget.itemWidget(self.list_widget.item(r)); (w.update_ui_silently(reg.names, reg.rect, reg.color, reg.shape_type, reg.next_json) if w else None)
        finally: self.is_updating = False

    def update_names_from_blender(self):
        # コンテキストに依存せず、現在のシーンの選択オブジェクトを確実に取得
        try:
            # bpy.context.selected_objects が空になることがあるため、シーン全体からセレクト状態を確認
            names = [obj.name for obj in bpy.data.objects if obj.select_get()]
            self.edit_names.setText(", ".join(names))
        except Exception as e:
            print(f"Update Names Error: {e}")

    def handle_pan(self, d):
        self.scroll.horizontalScrollBar().setValue(self.scroll.horizontalScrollBar().value()-d.x())
        self.scroll.verticalScrollBar().setValue(self.scroll.verticalScrollBar().value()-d.y())
    def handle_drop_file(self, p):
        ext = os.path.splitext(p)[1].lower()
        if ext in [".png", ".jpg", ".jpeg"]:
            self.canvas.set_image(QtGui.QPixmap(p)); self.scroll.setWidgetResizable(False)
            json_path = os.path.splitext(p)[0] + ".json"; (self.load_json(json_path) if os.path.exists(json_path) else None)
        elif ext == ".json": self.load_json(p)
    def batch_replace(self):
        f, r = self.edit_f.text(), self.edit_r.text()
        if f:
            for i, reg in enumerate(self.canvas.registered_items):
                if not reg.next_json:
                    reg.names = [n.replace(f, r) for n in reg.names]
                    w = self.list_widget.itemWidget(self.list_widget.item(i)); (w.update_ui_silently(reg.names, reg.rect, reg.color, reg.shape_type, reg.next_json) if w else None)
    def do_register(self):
        s = self.canvas.scale; r = self.canvas.temp_rect
        if r.isNull() or r.width() < 2 or r.height() < 2:
            raw = [10, 10, 50, 50]
        else:
            raw = [int(r.x()/s), int(r.y()/s), int(r.width()/s), int(r.height()/s)]
        names = [n.strip() for n in self.edit_names.text().split(",") if n.strip()] or ["Control"]
        reg = ClickRegion(names, raw, self.last_used_color); self.canvas.registered_items.append(reg)
        self.add_list_item(reg.names, reg.rect, reg.color, reg.shape_type)
        self.canvas.temp_rect = QtCore.QRect(); self.canvas.update()
    def add_list_item(self, names, rect, color, shape_type, next_json=""):
        it = QtWidgets.QListWidgetItem(self.list_widget); w = ListColorItem(names, rect, color, shape_type, next_json)
        w.names_changed.connect(self.sync_multi_names); w.rect_changed.connect(self.sync_multi_rect)
        w.color_changed.connect(self.sync_multi_color); w.type_changed.connect(self.sync_multi_type); w.next_json_changed.connect(self.sync_multi_next_json)
        it.setSizeHint(w.sizeHint()); self.list_widget.addItem(it); self.list_widget.setItemWidget(it, w)
    def delete_items(self):
        rows = sorted([i.row() for i in self.list_widget.selectedIndexes()], reverse=True)
        for r in rows:
            if r < len(self.canvas.registered_items): self.list_widget.takeItem(r); self.canvas.registered_items.pop(r)
        self.canvas.update()
    def toggle_mode(self, checked):
        self.canvas.mode = "selector" if checked else "setup"; self.setup_group.setEnabled(not checked); self.btn_reg.setEnabled(not checked); self.btn_del.setEnabled(not checked)
        for i in range(self.list_widget.count()):
            w = self.list_widget.itemWidget(self.list_widget.item(i)); (w.set_edit_enabled(not checked) if w else None)
    def save_json(self):
        p, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save JSON", self.current_json_path, "*.json")
        if p:
            lines = []
            for i in self.canvas.registered_items:
                path = os.path.basename(i.next_json) if i.next_json else ""
                lines.append(json.dumps({"names": i.names, "rect": list(i.rect.getRect()), "color": list(i.color.getRgb()), "shape_type": i.shape_type, "next_json": path}, ensure_ascii=False))
            with open(p, 'w', encoding='utf-8') as f: f.write("[\n" + ",\n".join(lines) + "\n]"); self.current_json_path = p
    def load_json(self, p=None):
        if not p: p, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Open JSON", self.current_json_path, "*.json")
        if p and os.path.exists(p):
            self.current_json_path = p; base_dir = os.path.dirname(p)
            with open(p, 'r', encoding='utf-8') as f: data = json.load(f)
            self.canvas.registered_items = []; self.list_widget.clear()
            for d in data:
                path = d.get("next_json", ""); rel = os.path.basename(path) if path else ""
                reg = ClickRegion(d.get("names", []), d["rect"], d["color"], d.get("shape_type", "rect"), (os.path.join(base_dir, rel) if rel else ""))
                self.canvas.registered_items.append(reg); self.add_list_item(reg.names, reg.rect, reg.color, reg.shape_type, rel)
            self.canvas.update()

def get_qapp():
    instance = QtWidgets.QApplication.instance(); return instance if instance else QtWidgets.QApplication(['blender'])
_picker_window = None

class PICKER_OT_RunEditor(bpy.types.Operator):
    bl_idname = "picker.run_editor"; bl_label = "Run Picker Editor"
    def execute(self, context):
        global _picker_window
        if _picker_window:
            try: _picker_window.close(); _picker_window.deleteLater()
            except: pass
            _picker_window = None
        app = get_qapp(); parent = next((w for w in QtWidgets.QApplication.topLevelWidgets() if "Blender" in w.windowTitle()), None)
        try: _picker_window = BlenderPickerEditor(parent=parent); _picker_window.setWindowFlags(_picker_window.windowFlags() | QtCore.Qt.Window); _picker_window.show()
        except Exception as e: self.report({'ERROR'}, f"Launch Error: {str(e)}"); return {'CANCELLED'}
        return {'FINISHED'}

class PICKER_PT_MainPanel(bpy.types.Panel):
    bl_label = "Picker Editor"; bl_idname = "PICKER_PT_MainPanel"; bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'Picker'
    def draw(self, context): self.layout.operator("picker.run_editor", text="Open Editor", icon='EDITMODE_HLT')

classes = (PICKER_OT_RunEditor, PICKER_PT_MainPanel)
def register():
    for cls in classes: bpy.utils.register_class(cls)
def unregister():
    global _picker_window
    if _picker_window: _picker_window.close()
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
if __name__ == "__main__": register()
# -*- coding: utf-8 -*-
import json
import os
import bpy
from PySide6 import QtWidgets, QtCore, QtGui

_instances = []

class ClickRegion:
    def __init__(self, names, rect_data, color):
        self.names = names if isinstance(names, list) else [names]
        self.rect = QtCore.QRect(*rect_data)
        self.color = QtGui.QColor(*color) if isinstance(color, list) else QtGui.QColor(color)

class PickerCanvas(QtWidgets.QLabel):
    pan_requested = QtCore.Signal(QtCore.QPoint)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.registered_items = []
        self.selected_indices = set()
        self.origin = QtCore.QPoint()
        self.selection_rect = QtCore.QRect()
        self.is_dragging = False
        self.scale = 1.0
        self.pixmap_original = None
        self.last_pan_pos = None
        
        self.setMouseTracking(True)
        self.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignTop)
        self.setText("Drop Image or JSON")
        self.setStyleSheet("color: #888; background-color: #1a1a1a; border: None;")

    def set_image(self, pixmap):
        self.pixmap_original = pixmap
        self.scale = 1.0
        self.update_canvas_size()

    def update_canvas_size(self):
        if self.pixmap_original:
            new_size = self.pixmap_original.size() * self.scale
            self.setPixmap(self.pixmap_original.scaled(
                new_size, 
                QtCore.Qt.AspectRatioMode.KeepAspectRatio, 
                QtCore.Qt.TransformationMode.SmoothTransformation
            ))
            # スクロールエリアにサイズ変更を通知するために必要
            self.setFixedSize(new_size)

    def wheelEvent(self, event):
        if not self.pixmap_original: return
        delta = event.angleDelta().y()
        old_scale = self.scale
        if delta > 0: self.scale *= 1.1
        else: self.scale /= 1.1
        self.scale = max(0.1, min(self.scale, 10.0))
        
        if old_scale != self.scale:
            self.update_canvas_size() # ここでサイズとPixmapを更新
            self.update()

    def paintEvent(self, event):
        super().paintEvent(event)
        if not self.pixmap(): return
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        
        for i, item in enumerate(self.registered_items):
            scaled_rect = QtCore.QRect(
                item.rect.x() * self.scale, item.rect.y() * self.scale,
                item.rect.width() * self.scale, item.rect.height() * self.scale
            )
            painter.setPen(QtGui.QPen(item.color, 4 if i in self.selected_indices else 1))
            painter.drawRect(scaled_rect)

        if self.is_dragging and not self.selection_rect.isNull():
            painter.setPen(QtGui.QPen(QtCore.Qt.GlobalColor.white, 1, QtCore.Qt.PenStyle.DashLine))
            painter.setBrush(QtGui.QColor(255, 255, 255, 40))
            painter.drawRect(self.selection_rect)

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.MiddleButton or \
           (event.button() == QtCore.Qt.MouseButton.LeftButton and event.modifiers() & QtCore.Qt.KeyboardModifier.AltModifier):
            self.last_pan_pos = event.globalPosition().toPoint()
            self.setCursor(QtCore.Qt.CursorShape.ClosedHandCursor)
            return
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.origin = event.position().toPoint()
            self.selection_rect = QtCore.QRect(self.origin, QtCore.QSize())
            self.is_dragging = False

    def mouseMoveEvent(self, event):
        if self.last_pan_pos:
            delta = event.globalPosition().toPoint() - self.last_pan_pos
            self.pan_requested.emit(delta)
            self.last_pan_pos = event.globalPosition().toPoint()
            return
        
        if event.buttons() & QtCore.Qt.MouseButton.LeftButton:
            if not self.is_dragging:
                if (event.position().toPoint() - self.origin).manhattanLength() > 5:
                    self.is_dragging = True
            
            if self.is_dragging:
                self.selection_rect = QtCore.QRect(self.origin, event.position().toPoint()).normalized()
                self.update()

    def mouseReleaseEvent(self, event):
        self.last_pan_pos = None
        self.setCursor(QtCore.Qt.CursorShape.ArrowCursor)
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            if event.modifiers() & QtCore.Qt.KeyboardModifier.AltModifier: return
            is_shift = (QtWidgets.QApplication.keyboardModifiers() == QtCore.Qt.KeyboardModifier.ShiftModifier)
            
            if self.is_dragging:
                new_selections = set()
                for i, item in enumerate(self.registered_items):
                    scaled_rect = QtCore.QRect(item.rect.x()*self.scale, item.rect.y()*self.scale, 
                                             item.rect.width()*self.scale, item.rect.height()*self.scale)
                    if self.selection_rect.intersects(scaled_rect): new_selections.add(i)
                if is_shift: self.selected_indices |= new_selections
                else: self.selected_indices = new_selections
            else:
                raw_pos = QtCore.QPoint(self.origin.x() / self.scale, self.origin.y() / self.scale)
                hit_index = -1
                for i, region in enumerate(self.registered_items):
                    if region.rect.contains(raw_pos): hit_index = i; break
                if hit_index != -1:
                    if is_shift:
                        if hit_index in self.selected_indices: self.selected_indices.remove(hit_index)
                        else: self.selected_indices.add(hit_index)
                    else: self.selected_indices = {hit_index}
                elif not is_shift: self.selected_indices.clear()

            self._update_blender_selection(is_shift)
            self.is_dragging = False
            self.selection_rect = QtCore.QRect()
            self.update()

    def _update_blender_selection(self, is_shift):
        if not is_shift: bpy.ops.object.select_all(action='DESELECT')
        for idx in self.selected_indices:
            for name in self.registered_items[idx].names:
                obj = bpy.data.objects.get(name)
                if obj:
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj

class PickerPlayer(QtWidgets.QWidget):
    def __init__(self, title="Picker Player"):
        super().__init__()
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowTitle(title)
        self.setWindowFlags(QtCore.Qt.Window | QtCore.Qt.WindowStaysOnTopHint)
        self.setAcceptDrops(True)
        self.setFixedSize(160, 25)
        self.first_load = True
        
        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidgetResizable(False) # 固定サイズウィジェットをスクロールさせるため
        self.scroll.setStyleSheet("background-color: #1a1a1a; border: none;")
        self.canvas = PickerCanvas()
        self.scroll.setWidget(self.canvas)
        self.main_layout.addWidget(self.scroll)
        self.canvas.pan_requested.connect(self.handle_pan)

        self.setup_window_icon()

    def setup_window_icon(self):
        script_dir = os.path.dirname(__file__) if "__file__" in globals() else ""
        icon_path = os.path.join(script_dir, "PickerPlayer.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QtGui.QIcon(icon_path))

    def handle_pan(self, delta):
        h, v = self.scroll.horizontalScrollBar(), self.scroll.verticalScrollBar()
        h.setValue(h.value() - delta.x()); v.setValue(v.value() - delta.y())

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()
    def dropEvent(self, event):
        for url in event.mimeData().urls(): self.load_resource(url.toLocalFile())
        event.acceptProposedAction()

    def load_resource(self, path):
        ext = os.path.splitext(path)[1].lower()
        if ext in [".png", ".jpg", ".jpeg"]:
            pix = QtGui.QPixmap(path)
            if not pix.isNull():
                self.setWindowTitle(f"Picker: {os.path.basename(path)}")
                self.canvas.setText(""); self.canvas.set_image(pix)
                if self.first_load:
                    self.setMinimumSize(0, 0); self.setMaximumSize(16777215, 16777215)
                    self.setFixedSize(pix.size()); self.setMinimumSize(100, 100)
                    self.first_load = False
                json_path = os.path.splitext(path)[0] + ".json"
                if os.path.exists(json_path): self.load_json(json_path)

    def load_json(self, path):
        try:
            with open(path, 'r', encoding='utf-8') as f: data = json.load(f)
            self.canvas.registered_items = []
            self.canvas.selected_indices.clear()
            for d in data:
                self.canvas.registered_items.append(ClickRegion(d.get("names", [d.get("name", "Unknown")]), d["rect"], d.get("color", [0, 255, 0])))
            self.canvas.update()
        except: pass

    def closeEvent(self, event):
        if self in _instances: _instances.remove(self)
        super().closeEvent(event)

@bpy.app.handlers.persistent
def process_pyside_events_handler(scene):
    if not _instances: return
    app = QtWidgets.QApplication.instance()
    if app: app.processEvents(QtCore.QEventLoop.ProcessEventsFlag.AllEvents, 5)

def run_player():
    global _instances
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    new_win = PickerPlayer(f"Picker Player {len(_instances) + 1}")
    new_win.show()
    _instances.append(new_win)
    if process_pyside_events_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(process_pyside_events_handler)

class PICKER_OT_RunPlayer(bpy.types.Operator):
    bl_idname = "picker.run_player"; bl_label = "Run Picker Player"
    def execute(self, context): run_player(); return {'FINISHED'}

class PICKER_PT_PlayerPanel(bpy.types.Panel):
    bl_label = "Picker Player"; bl_idname = "PICKER_PT_PlayerPanel"
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = 'Picker'
    def draw(self, context):
        self.layout.operator("picker.run_player", icon='PLAY')

def register():
    bpy.utils.register_class(PICKER_OT_RunPlayer)
    bpy.utils.register_class(PICKER_PT_PlayerPanel)

def unregister():
    if process_pyside_events_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(process_pyside_events_handler)
    for win in _instances[:]:
        try: win.close()
        except: pass
    _instances.clear()
    bpy.utils.unregister_class(PICKER_OT_RunPlayer)
    bpy.utils.unregister_class(PICKER_PT_PlayerPanel)

if __name__ == "__main__":
    register()
# -*- coding: utf-8 -*-
import json
import os
import bpy
from PySide6 import QtWidgets, QtCore, QtGui

# --- データ構造 ---
class ClickRegion:
    def __init__(self, names, rect_data, color):
        self.names = names if isinstance(names, list) else [names]
        self.rect = QtCore.QRect(*rect_data)
        self.color = QtGui.QColor(*color) if isinstance(color, list) else QtGui.QColor(color)

# --- カスタムキャンバス ---
class PickerCanvas(QtWidgets.QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.registered_items = []
        self.selected_indices = set()  # 複数選択の状態を保持
        
        # ドラッグ選択用の管理変数
        self.origin = QtCore.QPoint()
        self.selection_rect = QtCore.QRect()
        self.is_dragging = False
        
        self.setMouseTracking(True)
        self.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.setText("Drop Image or JSON File")
        self.setStyleSheet("color: #888; background-color: #1a1a1a; border: None;")
        self.setContentsMargins(0, 0, 0, 0)

    def paintEvent(self, event):
        super().paintEvent(event)
        if not self.pixmap(): return
        
        painter = QtGui.QPainter(self)
        painter.setRenderHint(QtGui.QPainter.Antialiasing)
        
        # アイテム枠の描画
        for i, item in enumerate(self.registered_items):
            is_selected = i in self.selected_indices
            pen_width = 4 if is_selected else 1
            painter.setPen(QtGui.QPen(item.color, pen_width))
            painter.drawRect(item.rect)

        # ドラッグ中の点線枠の描画
        if self.is_dragging and not self.selection_rect.isNull():
            painter.setPen(QtGui.QPen(QtCore.Qt.GlobalColor.white, 1, QtCore.Qt.PenStyle.DashLine))
            painter.setBrush(QtGui.QColor(255, 255, 255, 40))
            painter.drawRect(self.selection_rect)

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.origin = event.position().toPoint()
            self.selection_rect = QtCore.QRect(self.origin, QtCore.QSize())
            self.is_dragging = False

    def mouseMoveEvent(self, event):
        if event.buttons() & QtCore.Qt.MouseButton.LeftButton:
            # 5px以上の移動でドラッグと判定
            if (event.position().toPoint() - self.origin).manhattanLength() > 5:
                self.is_dragging = True
            
            if self.is_dragging:
                self.selection_rect = QtCore.QRect(self.origin, event.position().toPoint()).normalized()
                self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            modifiers = QtWidgets.QApplication.keyboardModifiers()
            is_shift = (modifiers == QtCore.Qt.KeyboardModifier.ShiftModifier)
            
            if self.is_dragging:
                # --- ドラッグによる範囲選択 ---
                new_selections = set()
                for i, item in enumerate(self.registered_items):
                    if self.selection_rect.intersects(item.rect):
                        new_selections.add(i)
                
                if is_shift:
                    self.selected_indices |= new_selections
                else:
                    self.selected_indices = new_selections
                self._update_blender_selection(is_shift)
                
            else:
                # --- 通常のクリック処理 ---
                pos = self.origin
                hit_index = -1
                for i, region in enumerate(self.registered_items):
                    if region.rect.contains(pos):
                        hit_index = i
                        break

                if hit_index != -1:
                    if is_shift:
                        if hit_index in self.selected_indices:
                            self.selected_indices.remove(hit_index)
                        else:
                            self.selected_indices.add(hit_index)
                    else:
                        self.selected_indices = {hit_index}
                    self._update_blender_selection(is_shift)
                else:
                    if not is_shift:
                        self.selected_indices.clear()
                        bpy.ops.object.select_all(action='DESELECT')

            self.is_dragging = False
            self.selection_rect = QtCore.QRect()
            self.update()

    def _update_blender_selection(self, is_shift):
        """現在の選択インデックスに基づいてBlenderのオブジェクト選択を更新"""
        if not is_shift:
            bpy.ops.object.select_all(action='DESELECT')

        for idx in self.selected_indices:
            region = self.registered_items[idx]
            for name in region.names:
                obj = bpy.data.objects.get(name)
                if obj:
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj

# --- メインウィンドウ ---
class PickerPlayer(QtWidgets.QWidget):
    def __init__(self, title="Picker Player"):
        super().__init__()
        self.setWindowTitle(title)
        self.setWindowFlags(QtCore.Qt.Window | QtCore.Qt.WindowStaysOnTopHint)
        self.setAcceptDrops(True)
        
        self.apply_window_icon()
        
        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)
        
        self.canvas = PickerCanvas()
        self.main_layout.addWidget(self.canvas)
        
        # 起動時はコンパクトなサイズに固定
        self.setFixedSize(160, 25)

    def apply_window_icon(self):
        try:
            script_path = os.path.realpath(__file__)
            script_dir = os.path.dirname(script_path)
            icon_path = os.path.join(script_dir, "PickerPlayer.png")
            if os.path.exists(icon_path):
                self.setWindowIcon(QtGui.QIcon(icon_path))
        except:
            pass

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()
    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()
    def dropEvent(self, event):
        for url in event.mimeData().urls():
            path = url.toLocalFile()
            if os.path.exists(path): self.load_resource(path)
        event.acceptProposedAction()

    def load_resource(self, path):
        ext = os.path.splitext(path)[1].lower()
        if ext in [".png", ".jpg", ".jpeg"]:
            pix = QtGui.QPixmap(path)
            if not pix.isNull():
                self.setWindowTitle(f"Picker: {os.path.basename(path)}")
                self.canvas.setText("")
                self.canvas.setPixmap(pix)
                
                # 固定解除して画像サイズにリサイズ
                self.setMinimumSize(0, 0)
                self.setMaximumSize(16777215, 16777215)
                self.canvas.setFixedSize(pix.size())
                self.setFixedSize(pix.size()) 
                
                json_path = os.path.splitext(path)[0] + ".json"
                if os.path.exists(json_path): self.load_json(json_path)
        elif ext == ".json":
            self.load_json(path)

    def load_json(self, path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.canvas.registered_items = []
            self.canvas.selected_indices.clear()
            for d in data:
                color = d.get("color", [0, 255, 0])
                names = d.get("names", [d.get("name", "Unknown")])
                region = ClickRegion(names, d["rect"], color)
                self.canvas.registered_items.append(region)
            self.canvas.update()
        except Exception as e:
            print(f"Picker Player Load Error: {e}")

    def closeEvent(self, event):
        if self in _instances:
            _instances.remove(self)
        super().closeEvent(event)

# --- 実行制御 ---
_instances = []

def process_pyside_events():
    if not _instances:
        return 0.1
    app = QtWidgets.QApplication.instance()
    if app:
        app.processEvents(QtCore.QEventLoop.ProcessEventsFlag.AllEvents, 5)
    return 0.01

def run_player():
    global _instances
    app = QtWidgets.QApplication.instance()
    if not app:
        app = QtWidgets.QApplication([])

    new_win = PickerPlayer(f"Picker Player {len(_instances) + 1}")
    new_win.show()
    _instances.append(new_win)

    if not bpy.app.timers.is_registered(process_pyside_events):
        bpy.app.timers.register(process_pyside_events)

# --- Blender UI 登録 ---
class PICKER_OT_RunPlayer(bpy.types.Operator):
    bl_idname = "picker.run_player" 
    bl_label = "Run Picker Player"

    def execute(self, context):
        run_player()
        return {'FINISHED'}

class PICKER_PT_PlayerPanel(bpy.types.Panel):
    bl_label = "Picker Player"
    bl_idname = "PICKER_PT_PlayerPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Picker'

    def draw(self, context):
        self.layout.operator("picker.run_player", text="Open Player", icon='PLAY')

classes = (PICKER_OT_RunPlayer, PICKER_PT_PlayerPanel)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    if bpy.app.timers.is_registered(process_pyside_events):
        bpy.app.timers.unregister(process_pyside_events)
    for win in _instances[:]:
        win.close()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
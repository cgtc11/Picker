# -*- coding: utf-8 -*-
import json
import os
import bpy
from PySide6 import QtWidgets, QtCore, QtGui

# --- データ構造 ---
class ClickRegion:
    def __init__(self, names, rect_data, color):
        self.names = names if isinstance(names, list) else [names]
        self.rect = QtCore.QRect(*rect_data)
        self.color = QtGui.QColor(*color) if isinstance(color, list) else QtGui.QColor(color)

# --- カスタムキャンバス ---
class PickerCanvas(QtWidgets.QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.registered_items = []
        self.selected_index = -1
        self.setMouseTracking(True)
        self.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignTop)
        self.setText("Drop Image or JSON File")
        self.setStyleSheet("color: #888; background-color: #1a1a1a; border: None;")
        self.setContentsMargins(0, 0, 0, 0)

    def paintEvent(self, event):
        super().paintEvent(event)
        if not self.pixmap(): return
        painter = QtGui.QPainter(self)
        for i, item in enumerate(self.registered_items):
            pen_width = 4 if i == self.selected_index else 1
            painter.setPen(QtGui.QPen(item.color, pen_width))
            painter.drawRect(item.rect)

    def mousePressEvent(self, event):
        pos = event.position().toPoint()
        hit = False
        modifiers = QtWidgets.QApplication.keyboardModifiers()
        is_shift = (modifiers == QtCore.Qt.KeyboardModifier.ShiftModifier)

        for i, region in enumerate(self.registered_items):
            if region.rect.contains(pos):
                hit = True
                self.selected_index = i
                self.update()
                
                if not is_shift:
                    bpy.ops.object.select_all(action='DESELECT')
                
                for name in region.names:
                    obj = bpy.data.objects.get(name)
                    if obj:
                        obj.select_set(True)
                        bpy.context.view_layer.objects.active = obj
                break
        
        if not hit:
            self.selected_index = -1
            bpy.ops.object.select_all(action='DESELECT')
            self.update()

# --- メインウィンドウ ---
class PickerPlayer(QtWidgets.QWidget):
    def __init__(self, title="Picker Player"):
        super().__init__()
        self.setWindowTitle(title)
        self.setWindowFlags(QtCore.Qt.Window | QtCore.Qt.WindowStaysOnTopHint)
        self.setAcceptDrops(True)
        
        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)
        
        self.canvas = PickerCanvas()
        self.main_layout.addWidget(self.canvas)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()
    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()
    def dropEvent(self, event):
        for url in event.mimeData().urls():
            path = url.toLocalFile()
            if os.path.exists(path): self.load_resource(path)
        event.acceptProposedAction()

    def load_resource(self, path):
        ext = os.path.splitext(path)[1].lower()
        if ext in [".png", ".jpg", ".jpeg"]:
            pix = QtGui.QPixmap(path)
            if not pix.isNull():
                self.setWindowTitle(f"Picker: {os.path.basename(path)}")
                self.canvas.setText("")
                self.canvas.setPixmap(pix)
                self.canvas.setFixedSize(pix.size())
                self.setFixedSize(pix.size()) 
                
                json_path = os.path.splitext(path)[0] + ".json"
                if os.path.exists(json_path): self.load_json(json_path)
        elif ext == ".json":
            self.load_json(path)

    def load_json(self, path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.canvas.registered_items = []
            for d in data:
                color = d.get("color", [0, 255, 0])
                names = d.get("names", [d.get("name", "Unknown")])
                region = ClickRegion(names, d["rect"], color)
                self.canvas.registered_items.append(region)
            self.canvas.update()
        except Exception as e:
            print(f"Picker Player Load Error: {e}")

    def closeEvent(self, event):
        if self in _instances:
            _instances.remove(self)
        super().closeEvent(event)

# --- 実行制御 (ハンドラ方式：リサイズ耐性アップ) ---
_instances = []

def process_pyside_events(scene):
    """Blenderの描画更新の隙間にPySideのイベントを処理"""
    if not _instances:
        if process_pyside_events in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.remove(process_pyside_events)
        return
    
    app = QtWidgets.QApplication.instance()
    if app:
        # タイムアウト付きでイベントをさばく
        app.processEvents(QtCore.QEventLoop.ProcessEventsFlag.AllEvents, 5)

def run_player():
    global _instances
    app = QtWidgets.QApplication.instance()
    if not app:
        app = QtWidgets.QApplication([])

    new_win = PickerPlayer(f"Picker Player {len(_instances) + 1}")
    new_win.show()
    _instances.append(new_win)

    # ハンドラを登録（重複チェック）
    if process_pyside_events not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(process_pyside_events)

# --- Blender UI 登録セクション ---

class PICKER_OT_RunPlayer(bpy.types.Operator):
    bl_idname = "picker.run_player" 
    bl_label = "Run Picker Player"
    bl_description = "Open a new Picker Player window"

    def execute(self, context):
        run_player()
        return {'FINISHED'}

class PICKER_PT_PlayerPanel(bpy.types.Panel):
    bl_label = "Picker Player"
    bl_idname = "PICKER_PT_PlayerPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Picker'

    def draw(self, context):
        self.layout.operator("picker.run_player", text="Open Player", icon='PLAY')

classes = (
    PICKER_OT_RunPlayer,
    PICKER_PT_PlayerPanel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    # 登録解除時に確実にハンドラを削除
    if process_pyside_events in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(process_pyside_events)
        
    for win in _instances[:]:
        win.close()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
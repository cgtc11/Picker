bl_info = {
    "name": "Custom Picker Tool",
    "author": "DigiMonkey",
    "version": (0, 1),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Custom Picker", # 実際の場所に合わせて変更
    "description": "Editor and Player for Custom Pickers",
    "category": "System"
}

# 再読み込み（Reload Scripts）への対応
if "bpy" in locals():
    import importlib
    importlib.reload(PickerPlayer_Blender)
    importlib.reload(PickerEditor_Blender)
else:
    from . import PickerPlayer_Blender
    from . import PickerEditor_Blender

import bpy

def register():
    PickerPlayer_Blender.register()
    PickerEditor_Blender.register()

def unregister():
    # 登録解除は逆順に行うのが安全な場合があります
    PickerEditor_Blender.unregister()
    PickerPlayer_Blender.unregister()

if __name__ == "__main__":
    register()